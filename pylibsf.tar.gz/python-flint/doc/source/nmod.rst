**nmod** -- integers mod n
===============================================================================

.. autoclass :: flint.nmod
  :members:
  :inherited-members:
  :undoc-members:

