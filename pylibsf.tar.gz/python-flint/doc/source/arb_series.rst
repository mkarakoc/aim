**arb_series** -- power series over real numbers
===============================================================================

.. autoclass :: flint.arb_series
  :members:
  :inherited-members:
  :undoc-members:

