**fmpz** -- integers
===============================================================================

.. autoclass :: flint.fmpz
  :members:
  :inherited-members:
  :undoc-members:

