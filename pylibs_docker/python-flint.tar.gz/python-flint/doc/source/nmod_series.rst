**nmod_series** -- power series over integers mod n
===============================================================================

.. autoclass :: flint.nmod_series
  :members:
  :inherited-members:
  :undoc-members:

