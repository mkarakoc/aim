**fmpq_series** -- power series over rational numbers
===============================================================================

.. autoclass :: flint.fmpq_series
  :members:
  :inherited-members:
  :undoc-members:

