**fmpq_poly** -- polynomials over rational numbers
===============================================================================

.. autoclass :: flint.fmpq_poly
  :members:
  :inherited-members:
  :undoc-members:

