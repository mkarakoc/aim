**fmpq_mat** -- matrices over rational numbers
===============================================================================

.. autoclass :: flint.fmpq_mat
  :members:
  :inherited-members:
  :undoc-members:

