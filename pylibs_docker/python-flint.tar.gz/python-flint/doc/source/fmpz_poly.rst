**fmpz_poly** -- polynomials over integers
===============================================================================

.. autoclass :: flint.fmpz_poly
  :members:
  :inherited-members:
  :undoc-members:

